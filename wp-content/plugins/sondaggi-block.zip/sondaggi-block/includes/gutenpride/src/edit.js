/**
 * Retrieves the translation of text.
 *
 * @see https://developer.wordpress.org/block-editor/packages/packages-i18n/
 */
import { __ } from '@wordpress/i18n';
import {useSelect} from  '@wordpress/data';
/**
 * React hook that is used to mark the block wrapper element.
 * It provides all the necessary props like the class name.
 *
 * @see https://developer.wordpress.org/block-editor/packages/packages-block-editor/#useBlockProps
 */
import { registerBlockType } from '@wordpress/blocks';
import { TextControl } from '@wordpress/components';
import { useEntityProp } from '@wordpress/core-data';
import { get_post_meta } from '@wordpress/components';

import {
    useBlockProps,
    ColorPalette,
    InspectorControls,
} from '@wordpress/block-editor';
import {FormTokenField}  from '@wordpress/components'
import { useState, useEffect } from '@wordpress/element';
/**
 * Lets webpack process CSS, SASS or SCSS files referenced in JavaScript files.
 * Those files can contain any CSS code that gets applied to the editor.
 *
 * @see https://www.npmjs.com/package/@wordpress/scripts#using-css
 */
import './editor.scss';

/**
 * The edit function describes the structure of your block in the context of the
 * editor. This represents what the editor will render when the block is used.
 *
 * @see https://developer.wordpress.org/block-editor/developers/block-api/block-edit-save/#edit
 *
 * @return {WPElement} Element to render.
 */
export default function Edit({ setAttributes, attributes }) {
	const posts = useSelect ( (select) =>{
		return select('core').getEntityRecords('postType', 'sondaggi');
	} );
	var questionListIDs = posts && posts.map((element) =>element.title.raw+' ('+element.id+')');
	var selectedQuestionString= [];
	if (attributes.idson){
		
		var selectedQuestion = posts && posts.find(element => element.id.toString()==attributes.idson.toString());
		if (selectedQuestion) selectedQuestionString = [selectedQuestion.title.raw+' ('+selectedQuestion.id+')'];

	}

	const postType = useSelect(
		( select ) => select( 'core/editor' ).getCurrentPostType(),
		[]
	);
	const [ meta, setMeta ] = useEntityProp( 'postType', postType, 'meta' );
	const metaFieldValue = meta[ 'sondaggio' ];
	/*const metaFieldValue2 = meta['myguten_register_post_meta']

	const metaSonndaggio = useSelect (
		(select) => {return select('core').getEntityRecord('postType', 'sondaggi', 636)},[]
	)
	console.log(metaSonndaggio)
*/
	return (
		<div { ...useBlockProps() }>
			<form>
				<p>
					{ __( selectedQuestion ? selectedQuestion.title.raw : 'Select a sondaggio', 'gutenpride' ) }
				</p>
				<input type='radio' id='answer1' name='answer' value=''></input>
				<label>$answer1</label><br></br>
				<input type='radio' id='answer2' name='answer' value=''></input>
				<label>$answer2</label><br></br>
				<input type='submit' value='Submit' id='submit' onClick={()=>{}}></input>
			</form>
			<InspectorControls key="setting">
                    <div id="gutenpride-controls">
                            <FormTokenField
								value = {selectedQuestionString}
								suggestions = { questionListIDs }
								maxLength = {1}
								onChange = {
									(value) => {
										if(value[0]){
											var idstr = value[0].slice(0,-1).toString();
											idstr = idstr.split(' (').pop().toString();
											setAttributes({idson: idstr});
											setSelectedQuestionString(value);
										}
										else{
											setAttributes({idson: ""});
											setSelectedQuestionString([]);
										}
									}
								} 
							/>
                    </div>
                </InspectorControls>
		</div>
		
	);
}
