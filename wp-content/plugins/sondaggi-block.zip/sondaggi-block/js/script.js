
const form = document.querySelector('#sendForm');        
const radioButtons = document.querySelectorAll('input[name="choice"]');

form.addEventListener("submit", doStuff);

function doStuff(event){
	event.preventDefault();
    const radios = document.querySelectorAll('[name="choice"]');
    let selectedRadio;
	var index = 0;
    for (const radioButton of radioButtons) {
        if (radioButton.checked) {
            selectedRadio = index;
            break;
        }
		index++;
    }
	const idson = document.querySelector('#idson').innerHTML;        
	var formData = new FormData(form);
	formData.append("action", "send");
	formData.append("selected", selectedRadio);
	formData.append("idson", idson);

	var xhr = new XMLHttpRequest();
	xhr.open('POST','http://localhost/wordpress/wp-admin/admin-ajax.php', true);
	xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
	xhr.send(formData);

	//xhr.onload = function() {
	xhr.onreadystatechange = function() {
		if (xhr.readyState == 4 && xhr.status == 200) {
			alert("Form submitted successfully");
			console.log(xhr.responseText);

			const resultschart = document.querySelector('#resultChart');        
			resultschart.style.visibility='visible';
			const frontsondaggio = document.querySelector('#frontSondaggio');        
			frontsondaggio.style.visibility = 'invisible';
			
			document.querySelector('#bar'+index).innerHTML = document.querySelector('#bar'+index).innerHTML +1 ;        

		}
		
	}
/*
    var parameters_to_send = {selected: selectedRadio, idson: idson, action: "ajax_send" };

    fetch(`http://localhost/wordpress/wp-admin/admin-ajax.php`,{
        method:'POST',
        body: JSON.stringify(parameters_to_send),
			headers: {
				'Content-Type': 'application/json'
			}
    })
    .then(res => {
        if (res.ok) console.log('SUCCESS')
        else console.log('Not successful')

    })
    .then(data => console.log(data))
    .catch(err => console.error("Error:", err));
*/
}
/*
(function($){
	$(document).on('click','.more-link',function(e){
	 	e.preventDefault();
	 	//link = $(this);
	 	//id   = link.attr('href').replace(/^.*#more-/,'');
		$.ajax({
			url : ajax_obj.ajaxurl,
			type: 'post',
			data: {
				action : 'ajax_send',
				//id_post: id
				_ajax_nonce: my_ajax_obj.nonce, 
				parameters_to_send: this.parameters_to_send // data

			},
			beforeSend: function(){
				link.html('Cargando ...');
			},
			success: function(resultado){
				// $('#post-'+id).find('.entry-content').html(resultado);		
			}
		});
	});
})(jQuery);

querySelectorAll
addEventListener
*/