<?php
/**
 * Plugin Name: Sondaggi-Block
 * Description: This is a plugin demonstrating how to register new blocks for the Gutenberg editor.
 * Version: 1.1.0
 */
defined( 'ABSPATH' ) || exit;
require(dirname(__FILE__) . '/includes/gutenpride/gutenpride.php');
function sondaggi_block_script_register()
{
    register_block_type( __DIR__ );
}

add_action( 'init', 'sondaggi_block_script_register' );



/*
Plugin Name: Sidebar plugin

function sidebar_plugin_register() {
    wp_register_script(
        'plugin-sidebar-js',
        plugins_url( 'plugin-sidebar.js', __FILE__ ),
        array(
            'wp-plugins',
            'wp-edit-post',
            'wp-element',
            'wp-components'
        )
    );
}
add_action( 'init', 'sidebar_plugin_register' );
 
function sidebar_plugin_script_enqueue() {
    wp_enqueue_script( 'plugin-sidebar-js' );
}
add_action( 'enqueue_block_editor_assets', 'sidebar_plugin_script_enqueue' );
*/
   
function create_posttype() {
  
    register_post_type( 'sondaggi',
        array(
            'labels' => array(
                'name' => __( 'Sondaggi' ),
                'singular_name' => __( 'Sondaggi' )
            ),
            'public' => true,
            'has_archive' => true,
            'rewrite' => array('slug' => 'sondaggi'),
            'show_in_rest' => true,
            
  
        )
    );
}
add_action( 'init', 'create_posttype' );

function diwp_custom_metabox(){
 
    add_meta_box( 
                    'diwp-metabox',
                    'Information',
                    'diwp_custom_metabox_callback',
                    'sondaggi',
                    'normal'
                );
}
 
add_action('add_meta_boxes', 'diwp_custom_metabox');


function diwp_custom_metabox_callback(){
     
    global $post;
    $sondaggio = get_post_meta($post->ID, 'sondaggio', true)
    ?>
    <div class="row">
		<div class="label">Answer 1</div>
        <div class="fields">
            <input type="text" name="sondaggi_answer1" value="<?php if (isset($sondaggio['sondaggi_answer1']['text'])) {echo  $sondaggio['sondaggi_answer1']['text'];}?>"/>
			<label for="sondaggi_result1">Nº:</label>
			<input type="number" size="1" name="sondaggi_result1" value="<?php if (isset($sondaggio['sondaggi_answer1']['count'])) {echo $sondaggio['sondaggi_answer1']['count'];}?>"/>
		</div>
		<div class="label">Answer 2</div>
        <div class="fields">
            <input type="text" name="sondaggi_answer2" value="<?php if (isset($sondaggio['sondaggi_answer2']['text'])) {echo  $sondaggio['sondaggi_answer2']['text'];}?>"/>
			<label for="sondaggi_result2">Nº:</label>
			<input type="number" size="1" name="sondaggi_result2" value="<?php if (isset($sondaggio['sondaggi_answer2']['count'])) { echo $sondaggio['sondaggi_answer2']['count'];}?>"/>
		</div>
    </div>
    <?php

}

function diwp_save_custom_metabox(){
    global $post;

    if ( isset($_POST["sondaggi_answer1"]))
    {
    $sondaggio = [
        'sondaggi_answer1' => [
            'text' => $_POST["sondaggi_answer1"],
            'count' => $_POST["sondaggi_result1"]
        ],
        'sondaggi_answer2' =>[
            'text' => $_POST["sondaggi_answer2"],
            'count' => $_POST["sondaggi_result2"]
        ],
    ];
    update_post_meta($post->ID, 'sondaggio',$sondaggio);
    }

}
 
add_action('save_post', 'diwp_save_custom_metabox');



function add_register_post_meta() {
    register_meta( 'post', 'sondaggio', 
        array(
            'object_subtype' => 'sondaggi',
            'single' => true,
            'type' => 'string',
            'show_in_rest' => true
        )
    ); 
}
add_action( 'init', 'add_register_post_meta' );

/* 
function myguten_register_post_meta() {
    register_post_meta( 'post', 'myguten_meta_block_field', array(
        'show_in_rest' => true,
        'single' => true,
        'type' => 'string',
    ) );
}
add_action( 'init', 'myguten_register_post_meta' );
 */